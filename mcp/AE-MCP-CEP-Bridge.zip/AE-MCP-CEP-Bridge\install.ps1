param(
    [Parameter(Mandatory = $true)]
    [string]$SourceDir
)

$ErrorActionPreference = "Stop"

Write-Host "1) Procurando instalacoes do After Effects..." -ForegroundColor Cyan

$aeRoots = Get-ChildItem "C:\Program Files\Adobe" -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like "Adobe After Effects*" }

if (-not $aeRoots -or $aeRoots.Count -eq 0) {
    Write-Host "   Nenhuma instalacao do After Effects encontrada em C:\Program Files\Adobe." -ForegroundColor Yellow
} else {
    foreach ($ae in $aeRoots) {
        $startupDir = Join-Path $ae.FullName "Support Files\Scripts\Startup"
        $oldBridge = Join-Path $startupDir "ae-bridge.jsx"
        if (Test-Path $oldBridge) {
            Write-Host "   Encontrado script antigo em: $oldBridge" -ForegroundColor Yellow

            $backupDir = Join-Path $PSScriptRoot "backups"
            if (-not (Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
            $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
            $safeAeName = $ae.Name -replace '[\\/:*?"<>|]', '_'
            $backupPath = Join-Path $backupDir "ae-bridge.jsx.$safeAeName.$stamp.bak"
            Copy-Item -Path $oldBridge -Destination $backupPath -Force
            Write-Host "   Backup criado em: $backupPath" -ForegroundColor Green

            Rename-Item -Path $oldBridge -NewName "ae-bridge.jsx.disabled" -Force
            Write-Host "   Script antigo desativado (renomeado para .disabled)." -ForegroundColor Green
        } else {
            $disabled = Join-Path $startupDir "ae-bridge.jsx.disabled"
            if (Test-Path $disabled) {
                Write-Host "   [$($ae.Name)] script antigo ja estava desativado." -ForegroundColor DarkGray
            } else {
                Write-Host "   [$($ae.Name)] nenhum script antigo encontrado (ok)." -ForegroundColor DarkGray
            }
        }
    }
}

Write-Host ""
Write-Host "2) Instalando a extensao CEP..." -ForegroundColor Cyan

if (-not (Test-Path $SourceDir)) {
    throw "Pasta de origem da extensao nao encontrada: $SourceDir"
}

$targetUser = [Environment]::GetEnvironmentVariable("USERPROFILE")
$dest = Join-Path $targetUser "AppData\Roaming\Adobe\CEP\extensions\com.aemcp.bridge"

if (Test-Path $dest) {
    Remove-Item -Path $dest -Recurse -Force
}
New-Item -ItemType Directory -Path $dest -Force | Out-Null
Copy-Item -Path (Join-Path $SourceDir "*") -Destination $dest -Recurse -Force

Write-Host "   Extensao copiada para: $dest" -ForegroundColor Green

Write-Host ""
Write-Host "3) Habilitando modo debug do CEP (extensoes nao assinadas)..." -ForegroundColor Cyan

$targetSid = $null
try {
    $targetSid = (New-Object System.Security.Principal.NTAccount($env:USERNAME)).Translate([System.Security.Principal.SecurityIdentifier]).Value
} catch {
    $targetSid = $null
}

$versions = @("6", "7", "8", "9", "10", "11", "12")

function Set-DebugMode {
    param([string]$HiveRoot)
    foreach ($v in $versions) {
        $key = Join-Path $HiveRoot "Software\Adobe\CSXS.$v"
        if (-not (Test-Path $key)) { New-Item -Path $key -Force | Out-Null }
        New-ItemProperty -Path $key -Name "PlayerDebugMode" -Value "1" -PropertyType String -Force | Out-Null
    }
}

Set-DebugMode -HiveRoot "HKCU:"

if ($targetSid) {
    $hkuPath = "Registry::HKEY_USERS\$targetSid"
    if (Test-Path $hkuPath) {
        Set-DebugMode -HiveRoot "Registry::HKEY_USERS\$targetSid"
    }
}

Write-Host "   PlayerDebugMode habilitado para CSXS 6-12 (usuario atual)." -ForegroundColor Green

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Instalacao concluida!" -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Proximos passos:"
Write-Host "  1. Feche o After Effects completamente (se estiver aberto)."
Write-Host "  2. Abra o After Effects novamente."
Write-Host "  3. Va em Window > Extensions > AE MCP Bridge para abrir o painel."
Write-Host "  4. O painel deve mostrar 'aguardando tarefas...' - a ponte esta ativa."
Write-Host ""
