$ErrorActionPreference = "Stop"

Write-Host "1) Removendo a extensao CEP..." -ForegroundColor Cyan

$targetUser = [Environment]::GetEnvironmentVariable("USERPROFILE")
$dest = Join-Path $targetUser "AppData\Roaming\Adobe\CEP\extensions\com.aemcp.bridge"

if (Test-Path $dest) {
    Remove-Item -Path $dest -Recurse -Force
    Write-Host "   Removida: $dest" -ForegroundColor Green
} else {
    Write-Host "   Extensao nao encontrada (ja removida)." -ForegroundColor DarkGray
}

Write-Host ""
Write-Host "2) Restaurando script antigo do Startup (se existir)..." -ForegroundColor Cyan

$aeRoots = Get-ChildItem "C:\Program Files\Adobe" -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like "Adobe After Effects*" }

foreach ($ae in $aeRoots) {
    $startupDir = Join-Path $ae.FullName "Support Files\Scripts\Startup"
    $disabled = Join-Path $startupDir "ae-bridge.jsx.disabled"
    if (Test-Path $disabled) {
        Rename-Item -Path $disabled -NewName "ae-bridge.jsx" -Force
        Write-Host "   [$($ae.Name)] script antigo restaurado (ae-bridge.jsx)." -ForegroundColor Green
    } else {
        Write-Host "   [$($ae.Name)] nada para restaurar." -ForegroundColor DarkGray
    }
}

Write-Host ""
Write-Host "============================================" -ForegroundColor Cyan
Write-Host "  Desinstalacao concluida." -ForegroundColor Green
Write-Host "============================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "Obs: as chaves de registro PlayerDebugMode (HKCU\Software\Adobe\CSXS.*)"
Write-Host "nao foram removidas, pois podem ser usadas por outras extensoes CEP."
Write-Host "Reinicie o After Effects para aplicar as mudancas."
Write-Host ""
