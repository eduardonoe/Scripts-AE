@echo off
setlocal EnableDelayedExpansion
title AE MCP Bridge - Instalador

:: Auto-elevate to administrator (needed to disable the old Startup script)
net session >nul 2>&1
if %errorLevel% NEQ 0 (
    echo Solicitando permissao de administrador...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo ============================================
echo   AE MCP Bridge - Instalador
echo ============================================
echo.

set "SCRIPT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%install.ps1" -SourceDir "%SCRIPT_DIR%cep-bridge"

echo.
echo Instalacao concluida. Pressione qualquer tecla para fechar.
pause >nul
