@echo off
setlocal EnableDelayedExpansion
title AE MCP Bridge - Desinstalador

net session >nul 2>&1
if %errorLevel% NEQ 0 (
    echo Solicitando permissao de administrador...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo ============================================
echo   AE MCP Bridge - Desinstalador
echo ============================================
echo.

set "SCRIPT_DIR=%~dp0"
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%uninstall.ps1"

echo.
echo Remocao concluida. Pressione qualquer tecla para fechar.
pause >nul
