// AE MCP Bridge - host ExtendScript
// Loaded once by CEP when the panel is opened. Defines a function that is
// invoked ON DEMAND via CSInterface.evalScript() -- there is NO app.scheduleTask
// polling here, so After Effects never force-preempts a modal dialog.

function aemcp_runTask(code) {
  var evalResult = null;
  var errorMsg = null;
  try {
    evalResult = eval("(function() { " + code + " })()");
  } catch (err) {
    errorMsg = err.toString() + (err.line ? " (Linha " + err.line + ")" : "");
  }
  var response = {
    success: errorMsg === null,
    data: evalResult,
    error: errorMsg
  };
  try {
    return JSON.stringify(response);
  } catch (stringifyErr) {
    return JSON.stringify({ success: false, data: null, error: "Falha ao serializar resultado: " + stringifyErr.toString() });
  }
}
