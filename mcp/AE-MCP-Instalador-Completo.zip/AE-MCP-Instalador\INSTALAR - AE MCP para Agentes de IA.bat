@echo off
setlocal EnableDelayedExpansion
title AE MCP - Instalador Completo (After Effects + Agente de IA)

net session >nul 2>&1
if %errorLevel% NEQ 0 (
    echo Solicitando permissao de administrador...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo ================================================
echo   AE MCP - Instalador Completo
echo   (After Effects + conexao com agente de IA)
echo ================================================
echo.

set "SCRIPT_DIR=%~dp0"
set "SCRIPT_DIR_NOSLASH=%SCRIPT_DIR:~0,-1%"
powershell -NoProfile -ExecutionPolicy Bypass -File "%SCRIPT_DIR%install.ps1" -PackageDir "%SCRIPT_DIR_NOSLASH%"

echo.
echo Instalacao concluida. Pressione qualquer tecla para fechar.
pause >nul
