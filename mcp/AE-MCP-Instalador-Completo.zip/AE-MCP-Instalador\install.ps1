param(
    [Parameter(Mandatory = $true)]
    [string]$PackageDir
)

$ErrorActionPreference = "Stop"

function Refresh-Path {
    $env:Path = [System.Environment]::GetEnvironmentVariable("Path", "Machine") + ";" + [System.Environment]::GetEnvironmentVariable("Path", "User")
}

Write-Host "1) Verificando Node.js..." -ForegroundColor Cyan
Refresh-Path
$nodeOk = $null -ne (Get-Command node -ErrorAction SilentlyContinue)
if (-not $nodeOk) {
    Write-Host "   Node.js nao encontrado. Instalando via winget (LTS)..." -ForegroundColor Yellow
    winget install -e --id OpenJS.NodeJS.LTS --accept-package-agreements --accept-source-agreements
    Refresh-Path
    $nodeOk = $null -ne (Get-Command node -ErrorAction SilentlyContinue)
    if (-not $nodeOk) {
        throw "Nao foi possivel instalar o Node.js automaticamente. Instale manualmente em nodejs.org e rode este instalador de novo."
    }
}
$nodeVersion = node --version
Write-Host "   Node.js OK: $nodeVersion" -ForegroundColor Green

Write-Host ""
Write-Host "2) Copiando o servidor MCP..." -ForegroundColor Cyan
$serverDest = Join-Path $env:LOCALAPPDATA "AE-MCP\ae-mcp-server"
if (Test-Path $serverDest) { Remove-Item -Path $serverDest -Recurse -Force }
New-Item -ItemType Directory -Path $serverDest -Force | Out-Null
Copy-Item -Path (Join-Path $PackageDir "ae-mcp-server-src\*") -Destination $serverDest -Recurse -Force
Write-Host "   Copiado para: $serverDest" -ForegroundColor Green

Write-Host ""
Write-Host "3) Instalando dependencias (npm install)..." -ForegroundColor Cyan
Push-Location $serverDest
npm install --omit=dev --no-audit --no-fund
Pop-Location
Write-Host "   Dependencias instaladas." -ForegroundColor Green

Write-Host ""
Write-Host "4) Instalando a ponte CEP no After Effects..." -ForegroundColor Cyan

$aeRoots = Get-ChildItem "C:\Program Files\Adobe" -Directory -ErrorAction SilentlyContinue |
    Where-Object { $_.Name -like "Adobe After Effects*" }

if (-not $aeRoots -or $aeRoots.Count -eq 0) {
    Write-Host "   Nenhuma instalacao do After Effects encontrada. Pulei este passo." -ForegroundColor Yellow
} else {
    foreach ($ae in $aeRoots) {
        $startupDir = Join-Path $ae.FullName "Support Files\Scripts\Startup"
        $oldBridge = Join-Path $startupDir "ae-bridge.jsx"
        if (Test-Path $oldBridge) {
            $backupDir = Join-Path $PackageDir "backups"
            if (-not (Test-Path $backupDir)) { New-Item -ItemType Directory -Path $backupDir -Force | Out-Null }
            $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
            $safeAeName = $ae.Name -replace '[\\/:*?"<>|]', '_'
            Copy-Item -Path $oldBridge -Destination (Join-Path $backupDir "ae-bridge.jsx.$safeAeName.$stamp.bak") -Force
            Rename-Item -Path $oldBridge -NewName "ae-bridge.jsx.disabled" -Force
            Write-Host "   [$($ae.Name)] script antigo de polling desativado (com backup)." -ForegroundColor Green
        }
    }
}

$cepDest = Join-Path $env:APPDATA "Adobe\CEP\extensions\com.aemcp.bridge"
if (Test-Path $cepDest) { Remove-Item -Path $cepDest -Recurse -Force }
New-Item -ItemType Directory -Path $cepDest -Force | Out-Null
Copy-Item -Path (Join-Path $PackageDir "cep-bridge-src\*") -Destination $cepDest -Recurse -Force
Write-Host "   Extensao CEP instalada em: $cepDest" -ForegroundColor Green

$versions = @("6", "7", "8", "9", "10", "11", "12")
foreach ($v in $versions) {
    $key = "HKCU:\Software\Adobe\CSXS.$v"
    if (-not (Test-Path $key)) { New-Item -Path $key -Force | Out-Null }
    New-ItemProperty -Path $key -Name "PlayerDebugMode" -Value "1" -PropertyType String -Force | Out-Null
}
Write-Host "   Modo debug do CEP habilitado (extensao nao assinada)." -ForegroundColor Green

Write-Host ""
Write-Host "5) Gerando o trecho de configuracao para o agente de IA..." -ForegroundColor Cyan

$indexPath = (Join-Path $serverDest "dist\index.js") -replace '\\', '\\'
$snippet = @"
{
  "mcpServers": {
    "after-effects": {
      "type": "stdio",
      "command": "node",
      "args": [
        "$indexPath"
      ],
      "env": {}
    }
  }
}
"@

$snippetPath = Join-Path (Split-Path $serverDest -Parent) "mcp-config-snippet.json"
Set-Content -Path $snippetPath -Value $snippet -Encoding UTF8
Write-Host "   Snippet salvo em: $snippetPath" -ForegroundColor Green

Write-Host ""
Write-Host "================================================" -ForegroundColor Cyan
Write-Host "  Instalacao concluida!" -ForegroundColor Green
Write-Host "================================================" -ForegroundColor Cyan
Write-Host ""
Write-Host "O que foi instalado:"
Write-Host "  - Servidor MCP:  $serverDest"
Write-Host "  - Ponte CEP:     $cepDest"
Write-Host "  - Config pronta: $snippetPath"
Write-Host ""
Write-Host "Falta so isso, no agente de IA que voce vai usar:"
Write-Host ""
Write-Host "  Claude Code (este app): cole o conteudo de mcp-config-snippet.json"
Write-Host "  dentro da chave 'mcpServers' do projeto em ~\.claude.json"
Write-Host ""
Write-Host "  Claude Desktop: Configuracoes > Developer > Edit Config, e cole o"
Write-Host "  mesmo trecho dentro de claude_desktop_config.json"
Write-Host ""
Write-Host "  Cursor / Windsurf: cole dentro do arquivo mcp.json (menu de MCP"
Write-Host "  Servers das configuracoes)"
Write-Host ""
Write-Host "Depois, no After Effects: abra Window > Extensions > AE MCP Bridge"
Write-Host "para ativar a ponte (precisa ser feito uma vez por sessao do AE)."
Write-Host ""

notepad.exe $snippetPath
