# AE MCP - Instalador Completo

Este e o arquivo que voce leva para um Windows novo quando precisar
reinstalar a conexao entre o After Effects e um agente de IA (Claude Code,
Claude Desktop, Cursor, etc).

## Importante: isso NAO e "um arquivo que se joga dentro do app de IA"

Nenhum agente de IA (Claude, GPT, Cursor...) tem um mecanismo de "arraste
este arquivo aqui para instalar uma conexao". MCP (Model Context Protocol)
funciona por **configuracao**: voce edita um arquivo JSON do proprio agente
apontando para o servidor.

Este instalador automatiza **tudo o que da para automatizar**:
- Instala o Node.js (se faltar)
- Copia e instala o servidor MCP (`ae-mcp-server`)
- Instala a ponte CEP dentro do After Effects (sem o polling antigo que
  causava o erro de "modal dialog")
- Gera o **trecho exato de configuracao** (`mcp-config-snippet.json`) que
  voce so precisa colar no agente de IA escolhido - e abre esse arquivo
  automaticamente no Bloco de Notas no final.

## Como usar

1. Copie a pasta inteira `AE-MCP-Instalador` (ou o zip) para o Windows novo.
2. De **dois cliques** em:
   `INSTALAR - AE MCP para Agentes de IA.bat`
3. Aceite o pedido de permissao de administrador (UAC).
4. Aguarde - ele instala Node.js (se precisar), o servidor e a ponte do AE.
5. No final, um Bloco de Notas abre com o JSON pronto. Cole dentro do
   arquivo de configuracao do seu agente:

   | Agente          | Onde colar                                          |
   |-----------------|------------------------------------------------------|
   | Claude Code     | dentro de `mcpServers` no projeto, em `~/.claude.json` |
   | Claude Desktop  | Configuracoes > Developer > Edit Config (`claude_desktop_config.json`) |
   | Cursor          | `mcp.json` (Settings > MCP)                          |
   | Windsurf        | `mcp_config.json`                                    |

6. No After Effects, abra **Window > Extensions > AE MCP Bridge** para
   ativar a ponte (uma vez por sessao do AE).

## Remover

Rode `uninstall.bat` (tambem pede admin). Ele remove o servidor, a
extensao CEP, e restaura o script antigo do Startup se existia. Depois,
remova manualmente a entrada `after-effects` do `mcpServers` no agente que
voce usava.

## O que fica instalado (padrao)

- Servidor MCP: `%LOCALAPPDATA%\AE-MCP\ae-mcp-server`
- Ponte CEP: `%APPDATA%\Adobe\CEP\extensions\com.aemcp.bridge`
- Snippet de config: `%LOCALAPPDATA%\AE-MCP\mcp-config-snippet.json`
