@echo off
setlocal EnableDelayedExpansion
title AE MCP - Desinstalador Completo

net session >nul 2>&1
if %errorLevel% NEQ 0 (
    echo Solicitando permissao de administrador...
    powershell -NoProfile -Command "Start-Process -FilePath '%~f0' -Verb RunAs"
    exit /b
)

echo ================================================
echo   AE MCP - Desinstalador Completo
echo ================================================
echo.

powershell -NoProfile -ExecutionPolicy Bypass -Command ^
    "$server = Join-Path $env:LOCALAPPDATA 'AE-MCP'; " ^
    "if (Test-Path $server) { Remove-Item -Recurse -Force $server; Write-Host '   Servidor MCP removido.' -ForegroundColor Green } else { Write-Host '   Servidor MCP nao encontrado.' -ForegroundColor DarkGray }; " ^
    "$cep = Join-Path $env:APPDATA 'Adobe\CEP\extensions\com.aemcp.bridge'; " ^
    "if (Test-Path $cep) { Remove-Item -Recurse -Force $cep; Write-Host '   Extensao CEP removida.' -ForegroundColor Green } else { Write-Host '   Extensao CEP nao encontrada.' -ForegroundColor DarkGray }; " ^
    "$aeRoots = Get-ChildItem 'C:\Program Files\Adobe' -Directory -ErrorAction SilentlyContinue | Where-Object { $_.Name -like 'Adobe After Effects*' }; " ^
    "foreach ($ae in $aeRoots) { $disabled = Join-Path $ae.FullName 'Support Files\Scripts\Startup\ae-bridge.jsx.disabled'; if (Test-Path $disabled) { Rename-Item -Path $disabled -NewName 'ae-bridge.jsx' -Force; Write-Host \"   [$($ae.Name)] script antigo restaurado.\" -ForegroundColor Green } }"

echo.
echo Lembre-se de remover manualmente a entrada 'after-effects' do mcpServers
echo no agente de IA que voce usava (Claude Code / Claude Desktop / etc).
echo.
echo Remocao concluida. Pressione qualquer tecla para fechar.
pause >nul
